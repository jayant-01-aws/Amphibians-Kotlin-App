/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.amphibians.ui.theme

import androidx.compose.ui.graphics.Color

val md_theme_light_background = Color(0xFFFCFDF6)
val md_theme_light_surface = Color(0xFFFCFDF6)
val md_theme_light_surfaceVariant = Color(0xFFDEE5D8)

val md_theme_dark_background = Color(0xFF1A1C19)
val md_theme_dark_surface = Color(0xFF1A1C19)
val md_theme_dark_surfaceVariant = Color(0xFF424940)
